import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Languages, RotateCcw, Users, Edit3, LogOut, Eye, MoreVertical } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { useBudget } from '@/contexts/BudgetContext';
import { usePageViews } from '@/hooks/usePageViews';
import { formatNumber, cn } from '@/lib/utils';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';

export function Header() {
  const { profile, signOut, isAdmin } = useAuth();
  const { language, setLanguage, t, isRTL } = useI18n();
  const { clearBudget } = useBudget();
  const pageViews = usePageViews();
  const navigate = useNavigate();
  const location = useLocation();

  const [resetOpen, setResetOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLanguageToggle = () => {
    setLanguage(language === 'en' ? 'ar' : 'en');
  };

  const handleReset = () => {
    clearBudget();
    setResetOpen(false);
    navigate('/wizard');
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/auth');
  };

  const onDashboard = location.pathname.startsWith('/dashboard');

  return (
    <>
      <header className="sticky top-0 z-30 safe-top bg-white/80 backdrop-blur-xl border-b border-ink-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-4">
            {/* Brand */}
            <button
              onClick={() => navigate(profile ? '/dashboard' : '/auth')}
              className="flex items-center gap-2 shrink-0 group no-tap-highlight"
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold shadow-soft">
                Q
              </div>
              <span className="font-display text-lg sm:text-xl font-bold text-ink-900">
                {t('common.appName')}
              </span>
            </button>

            {/* Page views (visible on larger screens) */}
            {pageViews !== null && (
              <div className="hidden md:flex items-center gap-1.5 text-xs text-ink-500 px-3 py-1.5 bg-ink-50 rounded-full">
                <Eye className="w-3.5 h-3.5" />
                <span className="font-medium">{formatNumber(pageViews, language)}</span>
                <span>{t('header.pageViews')}</span>
              </div>
            )}

            {/* User session info + actions */}
            <div className="flex items-center gap-1 sm:gap-2 ms-auto">
              {/* Role badge - desktop only */}
              {profile && (
                <div
                  className={cn(
                    'hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium',
                    isAdmin ? 'bg-brand-50 text-brand-700' : 'bg-ink-100 text-ink-700'
                  )}
                >
                  <span
                    className={cn(
                      'w-1.5 h-1.5 rounded-full',
                      isAdmin ? 'bg-brand-500' : 'bg-ink-400'
                    )}
                  />
                  <span className="truncate max-w-[120px]">
                    {profile.fullName || profile.email.split('@')[0]}
                  </span>
                  <span className="text-ink-400">·</span>
                  <span>{isAdmin ? t('header.admin') : t('header.user')}</span>
                </div>
              )}

              {/* Language toggle - always visible */}
              <button
                onClick={handleLanguageToggle}
                className="btn-icon"
                aria-label={t('header.language')}
                title={t('header.language')}
              >
                <Languages className="w-5 h-5" />
                <span className="ms-1 text-xs font-bold uppercase">{language === 'en' ? 'ع' : 'EN'}</span>
              </button>

              {/* Desktop quick actions */}
              {profile && (
                <div className="hidden sm:flex items-center gap-1">
                  {onDashboard && (
                    <button
                      onClick={() => navigate('/wizard')}
                      className="btn-icon"
                      aria-label={t('header.backToWizard')}
                      title={t('header.backToWizard')}
                    >
                      <Edit3 className="w-5 h-5" />
                    </button>
                  )}
                  <button
                    onClick={() => setResetOpen(true)}
                    className="btn-icon"
                    aria-label={t('header.resetData')}
                    title={t('header.resetData')}
                  >
                    <RotateCcw className="w-5 h-5" />
                  </button>
                  {isAdmin && (
                    <button
                      onClick={() => navigate('/admin')}
                      className="btn-icon"
                      aria-label={t('header.manageUsers')}
                      title={t('header.manageUsers')}
                    >
                      <Users className="w-5 h-5" />
                    </button>
                  )}
                  <button
                    onClick={handleSignOut}
                    className="btn-icon text-ink-600 hover:text-danger-600"
                    aria-label={t('common.signOut')}
                    title={t('common.signOut')}
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              )}

              {/* Mobile overflow menu */}
              {profile && (
                <button
                  onClick={() => setMenuOpen(true)}
                  className="btn-icon sm:hidden"
                  aria-label="Menu"
                >
                  <MoreVertical className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Mobile menu sheet */}
      <Modal
        open={menuOpen}
        onClose={() => setMenuOpen(false)}
        title={profile?.fullName || profile?.email}
        description={isAdmin ? t('header.admin') : t('header.user')}
      >
        <div className="space-y-1">
          {pageViews !== null && (
            <div className="flex items-center justify-between p-3 bg-ink-50 rounded-xl mb-3">
              <div className="flex items-center gap-2 text-ink-600">
                <Eye className="w-4 h-4" />
                <span className="text-sm">{t('header.pageViews')}</span>
              </div>
              <span className="font-semibold text-ink-900">{formatNumber(pageViews, language)}</span>
            </div>
          )}

          {onDashboard && (
            <button
              onClick={() => {
                setMenuOpen(false);
                navigate('/wizard');
              }}
              className="w-full flex items-center gap-3 p-3 hover:bg-ink-50 rounded-xl transition-colors text-start"
            >
              <Edit3 className="w-5 h-5 text-ink-600" />
              <span className="text-ink-900 font-medium">{t('header.backToWizard')}</span>
            </button>
          )}

          <button
            onClick={() => {
              setMenuOpen(false);
              setResetOpen(true);
            }}
            className="w-full flex items-center gap-3 p-3 hover:bg-ink-50 rounded-xl transition-colors text-start"
          >
            <RotateCcw className="w-5 h-5 text-ink-600" />
            <span className="text-ink-900 font-medium">{t('header.resetData')}</span>
          </button>

          {isAdmin && (
            <button
              onClick={() => {
                setMenuOpen(false);
                navigate('/admin');
              }}
              className="w-full flex items-center gap-3 p-3 hover:bg-ink-50 rounded-xl transition-colors text-start"
            >
              <Users className="w-5 h-5 text-ink-600" />
              <span className="text-ink-900 font-medium">{t('header.manageUsers')}</span>
            </button>
          )}

          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-3 p-3 hover:bg-danger-50 rounded-xl transition-colors text-start"
          >
            <LogOut className="w-5 h-5 text-danger-600" />
            <span className="text-danger-600 font-medium">{t('common.signOut')}</span>
          </button>
        </div>
      </Modal>

      {/* Reset confirmation modal */}
      <Modal
        open={resetOpen}
        onClose={() => setResetOpen(false)}
        title={t('header.resetConfirmTitle')}
        description={t('header.resetConfirmMessage')}
        footer={
          <div className={cn('flex gap-3', isRTL ? 'flex-row-reverse' : '')}>
            <Button variant="secondary" fullWidth onClick={() => setResetOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button variant="danger" fullWidth onClick={handleReset}>
              {t('header.resetConfirmButton')}
            </Button>
          </div>
        }
      >
        <p className="text-sm text-ink-600">{t('header.resetConfirmMessage')}</p>
      </Modal>
    </>
  );
}
