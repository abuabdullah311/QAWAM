import type { HTMLAttributes, ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  variant?: 'default' | 'elevated' | 'flat';
  padding?: 'none' | 'sm' | 'md' | 'lg';
}

const variants = {
  default: 'bg-white border border-ink-100 shadow-soft',
  elevated: 'bg-white border border-ink-100 shadow-card',
  flat: 'bg-white border border-ink-100',
};

const paddings = {
  none: '',
  sm: 'p-4',
  md: 'p-5 sm:p-6',
  lg: 'p-6 sm:p-8',
};

export function Card({ children, variant = 'default', padding = 'md', className, ...props }: CardProps) {
  return (
    <div
      className={cn('rounded-2xl transition-shadow', variants[variant], paddings[padding], className)}
      {...props}
    >
      {children}
    </div>
  );
}
