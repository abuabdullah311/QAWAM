import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SUPPORTED_CURRENCIES } from '@/lib/budgetRules';
import type { Currency } from '@/types';

interface CurrencySelectProps {
  value: Currency;
  onChange: (currency: Currency) => void;
  label?: string;
}

export function CurrencySelect({ value, onChange, label }: CurrencySelectProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const selected = SUPPORTED_CURRENCIES.find(c => c.code === value) ?? SUPPORTED_CURRENCIES[0];

  useEffect(() => {
    if (!open) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [open]);

  return (
    <div className="w-full" ref={ref}>
      {label && <label className="block text-sm font-medium text-ink-700 mb-2">{label}</label>}
      <div className="relative">
        <button
          type="button"
          onClick={() => setOpen(o => !o)}
          className={cn(
            'w-full bg-white border border-ink-200 rounded-xl px-4 py-3',
            'flex items-center justify-between gap-2',
            'text-ink-900 transition-all duration-200',
            'hover:border-ink-300',
            'focus:outline-none focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10',
            'h-12'
          )}
          aria-haspopup="listbox"
          aria-expanded={open}
        >
          <span className="flex items-center gap-3">
            <span className="text-base font-semibold text-ink-900">{selected.code}</span>
            <span className="text-sm text-ink-500 truncate">{selected.label}</span>
          </span>
          <ChevronDown className={cn('w-5 h-5 text-ink-400 transition-transform', open && 'rotate-180')} />
        </button>

        {open && (
          <div className="absolute z-20 mt-2 w-full bg-white border border-ink-200 rounded-xl shadow-elevated overflow-hidden animate-scale-in origin-top">
            <ul role="listbox" className="max-h-64 overflow-y-auto py-1">
              {SUPPORTED_CURRENCIES.map(c => (
                <li key={c.code}>
                  <button
                    type="button"
                    role="option"
                    aria-selected={c.code === value}
                    onClick={() => {
                      onChange(c.code);
                      setOpen(false);
                    }}
                    className={cn(
                      'w-full flex items-center justify-between px-4 py-3 text-start',
                      'hover:bg-ink-50 active:bg-ink-100 transition-colors',
                      c.code === value && 'bg-brand-50'
                    )}
                  >
                    <span className="flex items-center gap-3">
                      <span className="text-base font-semibold text-ink-900">{c.code}</span>
                      <span className="text-sm text-ink-500">{c.label}</span>
                    </span>
                    {c.code === value && <Check className="w-4 h-4 text-brand-600" />}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
