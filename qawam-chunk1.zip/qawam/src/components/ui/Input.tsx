import { forwardRef, type InputHTMLAttributes, type ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
  leftIcon?: ReactNode;
  rightAddon?: ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { label, error, hint, leftIcon, rightAddon, className, id, ...props },
  ref
) {
  const inputId = id || props.name;

  return (
    <div className="w-full">
      {label && (
        <label htmlFor={inputId} className="block text-sm font-medium text-ink-700 mb-2">
          {label}
        </label>
      )}
      <div className="relative">
        {leftIcon && (
          <span className="absolute start-3 top-1/2 -translate-y-1/2 text-ink-400 pointer-events-none">
            {leftIcon}
          </span>
        )}
        <input
          ref={ref}
          id={inputId}
          className={cn(
            'w-full bg-white border rounded-xl px-4 py-3 text-ink-900 placeholder-ink-400',
            'transition-all duration-200',
            'focus:outline-none focus:border-brand-500 focus:ring-4 focus:ring-brand-500/10',
            'h-12 text-base', // 16px font prevents iOS zoom
            leftIcon && 'ps-11',
            rightAddon && 'pe-20',
            error ? 'border-danger-500 focus:border-danger-500 focus:ring-danger-500/10' : 'border-ink-200',
            className
          )}
          {...props}
        />
        {rightAddon && (
          <div className="absolute end-2 top-1/2 -translate-y-1/2">{rightAddon}</div>
        )}
      </div>
      {error ? (
        <p className="mt-1.5 text-sm text-danger-600">{error}</p>
      ) : hint ? (
        <p className="mt-1.5 text-sm text-ink-500">{hint}</p>
      ) : null}
    </div>
  );
});
