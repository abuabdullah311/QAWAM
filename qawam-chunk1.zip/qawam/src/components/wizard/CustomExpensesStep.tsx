import { useState } from 'react';
import { Plus, X, ArrowRight, FileText } from 'lucide-react';
import { useI18n } from '@/contexts/I18nContext';
import { useBudget } from '@/contexts/BudgetContext';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { CATEGORY_ICONS, CATEGORY_TO_ALLOCATION } from '@/lib/categories';
import { formatCurrency, generateId, cn } from '@/lib/utils';
import type { Expense, ExpenseCategory } from '@/types';

interface CustomExpensesStepProps {
  onNext: () => void;
}

interface DraftExpense {
  id: string;
  name: string;
  amount: string;
  category: ExpenseCategory;
}

export function CustomExpensesStep({ onNext }: CustomExpensesStepProps) {
  const { t, language, isRTL } = useI18n();
  const { currency, expenses, addExpense, deleteExpense, updateExpense } = useBudget();
  const [drafts, setDrafts] = useState<DraftExpense[]>(
    expenses.length === 0 ? [{ id: generateId(), name: '', amount: '', category: 'other' }] : []
  );

  const handleAddRow = () => {
    setDrafts(d => [...d, { id: generateId(), name: '', amount: '', category: 'other' }]);
  };

  const handleRemoveDraft = (id: string) => {
    setDrafts(d => d.filter(row => row.id !== id));
  };

  const handleUpdateDraft = (id: string, field: keyof DraftExpense, value: string) => {
    setDrafts(d => d.map(row => (row.id === id ? { ...row, [field]: value } : row)));
  };

  const handleCommit = () => {
    drafts.forEach(d => {
      if (d.name.trim() && parseFloat(d.amount) > 0) {
        addExpense({
          name: d.name.trim(),
          amount: parseFloat(d.amount),
          category: d.category,
          allocation: CATEGORY_TO_ALLOCATION[d.category],
        });
      }
    });
    setDrafts([]);
    onNext();
  };

  const totalCommitted = expenses.reduce((sum, e) => sum + e.amount, 0);
  const totalDrafted = drafts.reduce((sum, d) => sum + (parseFloat(d.amount) || 0), 0);
  const total = totalCommitted + totalDrafted;

  return (
    <div className="max-w-2xl mx-auto animate-slide-up">
      <div className="text-center mb-6 sm:mb-8">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-brand-50 text-brand-600 mb-4">
          <FileText className="w-7 h-7" />
        </div>
        <h2 className="font-display text-2xl sm:text-3xl font-bold text-ink-900 text-balance">
          {t('wizard.customExpenses.title')}
        </h2>
        <p className="mt-2 text-ink-600 text-balance">{t('wizard.customExpenses.subtitle')}</p>
      </div>

      {/* Already committed expenses */}
      {expenses.length > 0 && (
        <div className="space-y-2 mb-5">
          {expenses.map(expense => {
            const Icon = CATEGORY_ICONS[expense.category];
            return (
              <Card key={expense.id} padding="sm" className="!p-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-ink-50 text-ink-600 flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <input
                      type="text"
                      value={expense.name}
                      onChange={e => updateExpense(expense.id, { name: e.target.value })}
                      className="w-full bg-transparent border-0 p-0 text-ink-900 font-medium focus:outline-none focus:ring-0"
                    />
                  </div>
                  <input
                    type="number"
                    inputMode="decimal"
                    value={expense.amount}
                    onChange={e => updateExpense(expense.id, { amount: parseFloat(e.target.value) || 0 })}
                    className="w-24 text-end bg-transparent border-0 p-0 text-ink-900 font-semibold focus:outline-none focus:ring-0"
                    step="0.01"
                    dir="ltr"
                  />
                  <span className="text-xs text-ink-500 font-medium">{currency}</span>
                  <button
                    type="button"
                    onClick={() => deleteExpense(expense.id)}
                    className="shrink-0 w-9 h-9 flex items-center justify-center text-ink-400 hover:text-danger-600 hover:bg-danger-50 rounded-lg transition-colors"
                    aria-label="Delete"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Draft new expenses */}
      <div className="space-y-3 mb-4">
        {drafts.map(draft => (
          <Card key={draft.id} padding="sm" className="animate-fade-in">
            <div className="flex flex-col sm:flex-row gap-3">
              <Input
                type="text"
                placeholder={t('wizard.expenseWizard.namePlaceholder')}
                value={draft.name}
                onChange={e => handleUpdateDraft(draft.id, 'name', e.target.value)}
                autoFocus
              />
              <div className="flex gap-2 sm:w-48">
                <Input
                  type="number"
                  inputMode="decimal"
                  placeholder="0"
                  value={draft.amount}
                  onChange={e => handleUpdateDraft(draft.id, 'amount', e.target.value)}
                  step="0.01"
                  min="0"
                  dir="ltr"
                  rightAddon={
                    <span className="text-xs font-semibold text-ink-500 px-2">{currency}</span>
                  }
                />
                <button
                  type="button"
                  onClick={() => handleRemoveDraft(draft.id)}
                  className="shrink-0 w-12 h-12 flex items-center justify-center text-ink-400 hover:text-danger-600 hover:bg-danger-50 rounded-xl transition-colors"
                  aria-label="Remove"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <button
        type="button"
        onClick={handleAddRow}
        className={cn(
          'w-full flex items-center justify-center gap-2 py-3 mb-5',
          'border-2 border-dashed border-ink-200 rounded-xl',
          'text-ink-600 hover:text-brand-600 hover:border-brand-300 hover:bg-brand-50/30',
          'transition-colors'
        )}
      >
        <Plus className="w-5 h-5" />
        <span className="font-medium">
          {expenses.length === 0 && drafts.length === 0
            ? t('wizard.expenseWizard.addExpense')
            : t('wizard.customExpenses.addAnother')}
        </span>
      </button>

      {/* Total summary */}
      {total > 0 && (
        <Card padding="md" className="mb-5 bg-brand-50/50 border-brand-500/20">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-ink-700">
              {t('wizard.customExpenses.total')}
            </span>
            <span className="font-display text-xl font-bold text-brand-700">
              {formatCurrency(total, currency, language)}
            </span>
          </div>
        </Card>
      )}

      <Button
        fullWidth
        size="lg"
        onClick={handleCommit}
        disabled={expenses.length === 0 && drafts.every(d => !d.name.trim() || !parseFloat(d.amount))}
        rightIcon={<ArrowRight className={isRTL ? 'rotate-180 w-5 h-5' : 'w-5 h-5'} />}
      >
        {t('wizard.customExpenses.continueButton')}
      </Button>
    </div>
  );
}
