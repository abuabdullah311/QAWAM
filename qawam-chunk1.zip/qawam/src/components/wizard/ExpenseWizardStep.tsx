import { useState, useMemo } from 'react';
import { ArrowRight, Plus, X, SkipForward } from 'lucide-react';
import { useI18n } from '@/contexts/I18nContext';
import { useBudget } from '@/contexts/BudgetContext';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { ALL_CATEGORIES, CATEGORY_ICONS, CATEGORY_TO_ALLOCATION } from '@/lib/categories';
import { formatCurrency, generateId, cn } from '@/lib/utils';
import type { ExpenseCategory, Expense } from '@/types';

interface ExpenseWizardStepProps {
  onComplete: () => void;
  onSkipToManual: () => void;
}

interface DraftExpense {
  id: string;
  name: string;
  amount: string;
}

export function ExpenseWizardStep({ onComplete, onSkipToManual }: ExpenseWizardStepProps) {
  const { t, language, isRTL } = useI18n();
  const { currency, addExpense } = useBudget();
  const [categoryIndex, setCategoryIndex] = useState(0);
  const [drafts, setDrafts] = useState<DraftExpense[]>([{ id: generateId(), name: '', amount: '' }]);
  const [savedThisStep, setSavedThisStep] = useState<Expense[]>([]);

  const currentCategory: ExpenseCategory = ALL_CATEGORIES[categoryIndex];
  const Icon = CATEGORY_ICONS[currentCategory];
  const totalCategories = ALL_CATEGORIES.length;
  const isLast = categoryIndex === totalCategories - 1;

  const validDrafts = useMemo(
    () => drafts.filter(d => d.name.trim() && parseFloat(d.amount) > 0),
    [drafts]
  );

  const handleAddRow = () => {
    setDrafts(d => [...d, { id: generateId(), name: '', amount: '' }]);
  };

  const handleRemoveRow = (id: string) => {
    setDrafts(d => (d.length === 1 ? d : d.filter(row => row.id !== id)));
  };

  const handleUpdateRow = (id: string, field: 'name' | 'amount', value: string) => {
    setDrafts(d => d.map(row => (row.id === id ? { ...row, [field]: value } : row)));
  };

  const commitCurrent = () => {
    const added: Expense[] = [];
    validDrafts.forEach(draft => {
      const expense: Omit<Expense, 'id' | 'createdAt'> = {
        name: draft.name.trim(),
        amount: parseFloat(draft.amount),
        category: currentCategory,
        allocation: CATEGORY_TO_ALLOCATION[currentCategory],
      };
      addExpense(expense);
      added.push({ ...expense, id: draft.id, createdAt: new Date().toISOString() });
    });
    return added;
  };

  const handleNext = () => {
    const added = commitCurrent();
    setSavedThisStep(prev => [...prev, ...added]);
    setDrafts([{ id: generateId(), name: '', amount: '' }]);

    if (isLast) {
      onComplete();
    } else {
      setCategoryIndex(i => i + 1);
    }
  };

  const handleSkipCategory = () => {
    setDrafts([{ id: generateId(), name: '', amount: '' }]);
    if (isLast) {
      onComplete();
    } else {
      setCategoryIndex(i => i + 1);
    }
  };

  return (
    <div className="max-w-2xl mx-auto animate-slide-up">
      <div className="text-center mb-6 sm:mb-8">
        <h2 className="font-display text-2xl sm:text-3xl font-bold text-ink-900 text-balance">
          {t('wizard.expenseWizard.title')}
        </h2>
        <p className="mt-2 text-ink-600 text-balance">{t('wizard.expenseWizard.subtitle')}</p>
      </div>

      {/* Category indicator */}
      <Card padding="md" className="mb-5">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center shrink-0">
            <Icon className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-medium text-ink-500 mb-0.5">
              {t('wizard.expenseWizard.categoryProgress', {
                current: categoryIndex + 1,
                total: totalCategories,
              })}
            </div>
            <h3 className="font-display text-lg font-semibold text-ink-900 truncate">
              {t(`wizard.expenseWizard.categories.${currentCategory}` as never)}
            </h3>
            <p className="text-sm text-ink-500 truncate">
              {t(`wizard.expenseWizard.categoryDescriptions.${currentCategory}` as never)}
            </p>
          </div>
        </div>
      </Card>

      {/* Expense entry rows */}
      <div className="space-y-3 mb-4">
        {drafts.map((draft, idx) => (
          <Card key={draft.id} padding="sm" className="animate-fade-in">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1">
                <Input
                  type="text"
                  placeholder={t('wizard.expenseWizard.namePlaceholder')}
                  value={draft.name}
                  onChange={e => handleUpdateRow(draft.id, 'name', e.target.value)}
                  autoFocus={idx === drafts.length - 1 && idx === 0}
                />
              </div>
              <div className="flex gap-2 sm:w-48">
                <Input
                  type="number"
                  inputMode="decimal"
                  placeholder="0"
                  value={draft.amount}
                  onChange={e => handleUpdateRow(draft.id, 'amount', e.target.value)}
                  step="0.01"
                  min="0"
                  dir="ltr"
                  rightAddon={
                    <span className="text-xs font-semibold text-ink-500 px-2">{currency}</span>
                  }
                />
                {drafts.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveRow(draft.id)}
                    className="shrink-0 w-12 h-12 flex items-center justify-center text-ink-400 hover:text-danger-600 hover:bg-danger-50 rounded-xl transition-colors"
                    aria-label="Remove"
                  >
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>

      <button
        type="button"
        onClick={handleAddRow}
        className={cn(
          'w-full flex items-center justify-center gap-2 py-3 mb-5',
          'border-2 border-dashed border-ink-200 rounded-xl',
          'text-ink-600 hover:text-brand-600 hover:border-brand-300 hover:bg-brand-50/30',
          'transition-colors'
        )}
      >
        <Plus className="w-5 h-5" />
        <span className="font-medium">{t('wizard.expenseWizard.addExpense')}</span>
      </button>

      {/* Saved this session summary */}
      {savedThisStep.length > 0 && (
        <Card padding="sm" className="mb-5 bg-success-50/50 border-success-500/20">
          <div className="text-xs text-ink-600 mb-2">
            {savedThisStep.length} added so far —{' '}
            <span className="font-semibold text-ink-900">
              {formatCurrency(
                savedThisStep.reduce((sum, e) => sum + e.amount, 0),
                currency,
                language
              )}
            </span>
          </div>
        </Card>
      )}

      {/* Action buttons - stacked on mobile, side-by-side on larger */}
      <div className="space-y-3 sm:space-y-0 sm:flex sm:gap-3">
        <Button
          variant="secondary"
          fullWidth
          onClick={handleSkipCategory}
          leftIcon={<SkipForward className="w-4 h-4" />}
        >
          {t('wizard.expenseWizard.skipCategory')}
        </Button>
        <Button
          fullWidth
          onClick={handleNext}
          rightIcon={<ArrowRight className={isRTL ? 'rotate-180 w-5 h-5' : 'w-5 h-5'} />}
        >
          {isLast ? t('common.next') : t('wizard.expenseWizard.nextCategory')}
        </Button>
      </div>

      <button
        type="button"
        onClick={onSkipToManual}
        className="w-full mt-6 text-sm text-ink-500 hover:text-ink-700 transition-colors py-2"
      >
        {t('wizard.expenseWizard.skipToManual')}
      </button>
    </div>
  );
}
