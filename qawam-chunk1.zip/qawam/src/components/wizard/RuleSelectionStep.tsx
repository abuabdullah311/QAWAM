import { useState } from 'react';
import { Check, Sliders, ArrowRight } from 'lucide-react';
import { useI18n } from '@/contexts/I18nContext';
import { useBudget } from '@/contexts/BudgetContext';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Modal } from '@/components/ui/Modal';
import { BUDGET_RULES } from '@/lib/budgetRules';
import { cn, generateId } from '@/lib/utils';
import type { BudgetRule } from '@/types';

interface RuleSelectionStepProps {
  onNext: () => void;
}

export function RuleSelectionStep({ onNext }: RuleSelectionStepProps) {
  const { t, isRTL } = useI18n();
  const { ruleId, customRule, setRule } = useBudget();
  const [customOpen, setCustomOpen] = useState(false);
  const [customNeeds, setCustomNeeds] = useState(customRule?.needs ?? 50);
  const [customWants, setCustomWants] = useState(customRule?.wants ?? 30);
  const [customSavings, setCustomSavings] = useState(customRule?.savings ?? 20);

  const customTotal = customNeeds + customWants + customSavings;
  const isValidCustom = customTotal === 100;

  const handleSelectRule = (id: string) => {
    setRule(id, null);
  };

  const handleApplyCustom = () => {
    if (!isValidCustom) return;
    const newRule: BudgetRule = {
      id: 'custom',
      name: 'Custom',
      needs: customNeeds,
      wants: customWants,
      savings: customSavings,
      isCustom: true,
    };
    setRule('custom', newRule);
    setCustomOpen(false);
  };

  return (
    <div className="max-w-2xl mx-auto animate-slide-up">
      <div className="text-center mb-6 sm:mb-8">
        <h2 className="font-display text-2xl sm:text-3xl font-bold text-ink-900 text-balance">
          {t('wizard.ruleSelection.title')}
        </h2>
        <p className="mt-2 text-ink-600 text-balance">{t('wizard.ruleSelection.subtitle')}</p>
      </div>

      <div className="space-y-3 mb-5">
        {BUDGET_RULES.map(rule => {
          const selected = ruleId === rule.id;
          const ruleKey = rule.id as 'balanced' | 'aggressive' | 'zero';
          return (
            <button
              key={rule.id}
              type="button"
              onClick={() => handleSelectRule(rule.id)}
              className={cn(
                'w-full text-start p-5 rounded-2xl border-2 transition-all duration-200',
                'hover:border-brand-300 hover:bg-brand-50/30 active:scale-[0.99]',
                selected
                  ? 'border-brand-500 bg-brand-50/50 shadow-soft'
                  : 'border-ink-100 bg-white'
              )}
            >
              <div className="flex items-start gap-4">
                <div
                  className={cn(
                    'shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors mt-0.5',
                    selected ? 'border-brand-600 bg-brand-600' : 'border-ink-300'
                  )}
                >
                  {selected && <Check className="w-4 h-4 text-white" />}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-display text-lg font-semibold text-ink-900">
                    {t(`wizard.ruleSelection.rules.${ruleKey}.name` as never)}
                  </h3>
                  <p className="mt-1 text-sm text-ink-600">
                    {t(`wizard.ruleSelection.rules.${ruleKey}.description` as never)}
                  </p>
                  <div className="mt-3 flex gap-2 text-xs font-medium">
                    <span className="px-2 py-1 rounded-lg bg-brand-100 text-brand-700">
                      {t('wizard.ruleSelection.needs')} {rule.needs}%
                    </span>
                    <span className="px-2 py-1 rounded-lg bg-warning-50 text-warning-700">
                      {t('wizard.ruleSelection.wants')} {rule.wants}%
                    </span>
                    <span className="px-2 py-1 rounded-lg bg-success-50 text-success-700">
                      {t('wizard.ruleSelection.savings')} {rule.savings}%
                    </span>
                  </div>
                </div>
              </div>
            </button>
          );
        })}

        {/* Custom rule option */}
        <button
          type="button"
          onClick={() => setCustomOpen(true)}
          className={cn(
            'w-full text-start p-5 rounded-2xl border-2 transition-all duration-200',
            'hover:border-brand-300 hover:bg-brand-50/30 active:scale-[0.99]',
            ruleId === 'custom'
              ? 'border-brand-500 bg-brand-50/50 shadow-soft'
              : 'border-ink-100 bg-white'
          )}
        >
          <div className="flex items-start gap-4">
            <div
              className={cn(
                'shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors mt-0.5',
                ruleId === 'custom' ? 'border-brand-600 bg-brand-600' : 'border-ink-300'
              )}
            >
              {ruleId === 'custom' && <Check className="w-4 h-4 text-white" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="font-display text-lg font-semibold text-ink-900">
                  {t('wizard.ruleSelection.rules.custom.name')}
                </h3>
                <Sliders className="w-4 h-4 text-ink-400" />
              </div>
              <p className="mt-1 text-sm text-ink-600">
                {t('wizard.ruleSelection.rules.custom.description')}
              </p>
              {ruleId === 'custom' && customRule && (
                <div className="mt-3 flex gap-2 text-xs font-medium">
                  <span className="px-2 py-1 rounded-lg bg-brand-100 text-brand-700">
                    {t('wizard.ruleSelection.needs')} {customRule.needs}%
                  </span>
                  <span className="px-2 py-1 rounded-lg bg-warning-50 text-warning-700">
                    {t('wizard.ruleSelection.wants')} {customRule.wants}%
                  </span>
                  <span className="px-2 py-1 rounded-lg bg-success-50 text-success-700">
                    {t('wizard.ruleSelection.savings')} {customRule.savings}%
                  </span>
                </div>
              )}
            </div>
          </div>
        </button>
      </div>

      <Button
        size="lg"
        fullWidth
        onClick={onNext}
        rightIcon={<ArrowRight className={isRTL ? 'rotate-180 w-5 h-5' : 'w-5 h-5'} />}
      >
        {t('wizard.ruleSelection.continueButton')}
      </Button>

      {/* Custom rule modal */}
      <Modal
        open={customOpen}
        onClose={() => setCustomOpen(false)}
        title={t('wizard.ruleSelection.customizeTitle')}
        description={t('wizard.ruleSelection.customizeSubtitle')}
        footer={
          <div className={cn('flex gap-3', isRTL && 'flex-row-reverse')}>
            <Button variant="secondary" fullWidth onClick={() => setCustomOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button fullWidth onClick={handleApplyCustom} disabled={!isValidCustom}>
              {t('wizard.ruleSelection.apply')}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          <CustomSlider
            label={t('wizard.ruleSelection.needs')}
            value={customNeeds}
            onChange={setCustomNeeds}
            color="brand"
          />
          <CustomSlider
            label={t('wizard.ruleSelection.wants')}
            value={customWants}
            onChange={setCustomWants}
            color="warning"
          />
          <CustomSlider
            label={t('wizard.ruleSelection.savings')}
            value={customSavings}
            onChange={setCustomSavings}
            color="success"
          />
          <div
            className={cn(
              'flex items-center justify-between p-3 rounded-xl',
              isValidCustom ? 'bg-success-50 text-success-700' : 'bg-danger-50 text-danger-700'
            )}
          >
            <span className="text-sm font-medium">{t('wizard.ruleSelection.total')}</span>
            <span className="font-bold text-lg">{customTotal}%</span>
          </div>
          {!isValidCustom && (
            <p className="text-xs text-danger-600 text-center">{t('wizard.ruleSelection.mustEqual')}</p>
          )}
        </div>
      </Modal>
    </div>
  );
}

interface CustomSliderProps {
  label: string;
  value: number;
  onChange: (v: number) => void;
  color: 'brand' | 'warning' | 'success';
}

function CustomSlider({ label, value, onChange, color }: CustomSliderProps) {
  const trackColors = {
    brand: 'accent-brand-600',
    warning: 'accent-warning-600',
    success: 'accent-success-600',
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <label className="text-sm font-medium text-ink-700">{label}</label>
        <input
          type="number"
          value={value}
          onChange={e => {
            const v = Math.max(0, Math.min(100, parseInt(e.target.value) || 0));
            onChange(v);
          }}
          className="w-16 text-end px-2 py-1 bg-ink-50 border border-ink-200 rounded-lg text-sm font-semibold text-ink-900 focus:outline-none focus:border-brand-500"
          min="0"
          max="100"
          dir="ltr"
        />
      </div>
      <input
        type="range"
        min="0"
        max="100"
        value={value}
        onChange={e => onChange(parseInt(e.target.value))}
        className={cn('w-full h-2', trackColors[color])}
      />
    </div>
  );
}
