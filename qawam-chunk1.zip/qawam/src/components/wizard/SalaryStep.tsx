import { useState } from 'react';
import { Wallet, ArrowRight } from 'lucide-react';
import { useI18n } from '@/contexts/I18nContext';
import { useBudget } from '@/contexts/BudgetContext';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { CurrencySelect } from '@/components/ui/CurrencySelect';

interface SalaryStepProps {
  onNext: () => void;
}

export function SalaryStep({ onNext }: SalaryStepProps) {
  const { t, isRTL } = useI18n();
  const { salary, currency, setSalary, setCurrency } = useBudget();
  const [amount, setAmount] = useState(salary > 0 ? String(salary) : '');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(amount);
    if (!amount.trim()) {
      setError(t('wizard.salary.errors.required'));
      return;
    }
    if (isNaN(num)) {
      setError(t('wizard.salary.errors.invalid'));
      return;
    }
    if (num <= 0) {
      setError(t('wizard.salary.errors.tooLow'));
      return;
    }
    setSalary(num);
    onNext();
  };

  return (
    <div className="max-w-md mx-auto animate-slide-up">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-brand-50 text-brand-600 mb-4">
          <Wallet className="w-7 h-7" />
        </div>
        <h2 className="font-display text-2xl sm:text-3xl font-bold text-ink-900 text-balance">
          {t('wizard.salary.title')}
        </h2>
        <p className="mt-2 text-ink-600 text-balance">{t('wizard.salary.subtitle')}</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <CurrencySelect
          value={currency}
          onChange={setCurrency}
          label={t('wizard.salary.currencyLabel')}
        />

        <Input
          type="number"
          inputMode="decimal"
          name="salary"
          label={t('wizard.salary.amountLabel')}
          placeholder={t('wizard.salary.amountPlaceholder')}
          value={amount}
          onChange={e => {
            setAmount(e.target.value);
            if (error) setError('');
          }}
          error={error}
          autoFocus
          dir="ltr"
          step="0.01"
          min="0"
          rightAddon={
            <span className="text-sm font-semibold text-ink-500 px-3">{currency}</span>
          }
        />

        <Button
          type="submit"
          size="lg"
          fullWidth
          rightIcon={<ArrowRight className={isRTL ? 'rotate-180 w-5 h-5' : 'w-5 h-5'} />}
        >
          {t('wizard.salary.continue')}
        </Button>
      </form>
    </div>
  );
}
