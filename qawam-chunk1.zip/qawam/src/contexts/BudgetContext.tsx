import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';
import { generateId } from '@/lib/utils';
import { DEFAULT_RULE_ID } from '@/lib/budgetRules';
import type { Expense, BudgetRule, Currency } from '@/types';

interface BudgetState {
  salary: number;
  currency: Currency;
  ruleId: string;
  customRule: BudgetRule | null;
  expenses: Expense[];
}

interface BudgetContextValue extends BudgetState {
  setSalary: (salary: number) => void;
  setCurrency: (currency: Currency) => void;
  setRule: (ruleId: string, customRule?: BudgetRule | null) => void;
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => void;
  updateExpense: (id: string, updates: Partial<Omit<Expense, 'id' | 'createdAt'>>) => void;
  deleteExpense: (id: string) => void;
  clearBudget: () => void;
  hasBudget: boolean;
  syncing: boolean;
}

const STORAGE_KEY = 'qawam:budget';

const initialState: BudgetState = {
  salary: 0,
  currency: 'SAR',
  ruleId: DEFAULT_RULE_ID,
  customRule: null,
  expenses: [],
};

function loadFromStorage(): BudgetState {
  if (typeof window === 'undefined') return initialState;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return initialState;
    const parsed = JSON.parse(raw);
    return { ...initialState, ...parsed };
  } catch {
    return initialState;
  }
}

function saveToStorage(state: BudgetState) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

const BudgetContext = createContext<BudgetContextValue | null>(null);

export function BudgetProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [state, setState] = useState<BudgetState>(loadFromStorage);
  const [syncing, setSyncing] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  // Load from Supabase when user signs in
  useEffect(() => {
    if (!user) {
      setHydrated(true);
      return;
    }

    let mounted = true;
    (async () => {
      setSyncing(true);
      try {
        const { data, error } = await supabase
          .from('budgets')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (error) {
          console.error('Failed to load budget:', error);
          setHydrated(true);
          return;
        }

        if (data && mounted) {
          const remoteState: BudgetState = {
            salary: Number(data.salary) || 0,
            currency: (data.currency as Currency) || 'SAR',
            ruleId: data.rule_id || DEFAULT_RULE_ID,
            customRule: (data.custom_rule as BudgetRule | null) ?? null,
            expenses: Array.isArray(data.expenses) ? (data.expenses as Expense[]) : [],
          };
          setState(remoteState);
          saveToStorage(remoteState);
        }
      } finally {
        if (mounted) {
          setSyncing(false);
          setHydrated(true);
        }
      }
    })();

    return () => {
      mounted = false;
    };
  }, [user]);

  // Persist to LocalStorage and Supabase on change
  useEffect(() => {
    if (!hydrated) return;
    saveToStorage(state);

    if (user) {
      const timer = setTimeout(async () => {
        const { error } = await supabase.from('budgets').upsert(
          {
            user_id: user.id,
            salary: state.salary,
            currency: state.currency,
            rule_id: state.ruleId,
            custom_rule: state.customRule,
            expenses: state.expenses,
          },
          { onConflict: 'user_id' }
        );
        if (error) console.error('Budget sync failed:', error);
      }, 600); // Debounce remote sync

      return () => clearTimeout(timer);
    }
  }, [state, user, hydrated]);

  const setSalary = useCallback((salary: number) => {
    setState(prev => ({ ...prev, salary }));
  }, []);

  const setCurrency = useCallback((currency: Currency) => {
    setState(prev => ({ ...prev, currency }));
  }, []);

  const setRule = useCallback((ruleId: string, customRule: BudgetRule | null = null) => {
    setState(prev => ({ ...prev, ruleId, customRule }));
  }, []);

  const addExpense = useCallback((expense: Omit<Expense, 'id' | 'createdAt'>) => {
    const newExpense: Expense = {
      ...expense,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    setState(prev => ({ ...prev, expenses: [...prev.expenses, newExpense] }));
  }, []);

  const updateExpense = useCallback((id: string, updates: Partial<Omit<Expense, 'id' | 'createdAt'>>) => {
    setState(prev => ({
      ...prev,
      expenses: prev.expenses.map(e => (e.id === id ? { ...e, ...updates } : e)),
    }));
  }, []);

  const deleteExpense = useCallback((id: string) => {
    setState(prev => ({ ...prev, expenses: prev.expenses.filter(e => e.id !== id) }));
  }, []);

  const clearBudget = useCallback(() => {
    setState(initialState);
    if (user) {
      supabase.from('budgets').delete().eq('user_id', user.id);
    }
  }, [user]);

  const hasBudget = state.salary > 0 && state.expenses.length > 0;

  return (
    <BudgetContext.Provider
      value={{
        ...state,
        setSalary,
        setCurrency,
        setRule,
        addExpense,
        updateExpense,
        deleteExpense,
        clearBudget,
        hasBudget,
        syncing,
      }}
    >
      {children}
    </BudgetContext.Provider>
  );
}

export function useBudget() {
  const ctx = useContext(BudgetContext);
  if (!ctx) throw new Error('useBudget must be used within BudgetProvider');
  return ctx;
}
