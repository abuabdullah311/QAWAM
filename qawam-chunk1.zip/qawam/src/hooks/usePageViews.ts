import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export function usePageViews() {
  const [count, setCount] = useState<number | null>(null);

  useEffect(() => {
    let mounted = true;

    (async () => {
      // Increment the counter via RPC, then fetch the latest count.
      const { error: rpcError } = await supabase.rpc('increment_page_views');
      if (rpcError) {
        console.warn('Page view increment failed (non-critical):', rpcError.message);
      }

      const { data, error } = await supabase
        .from('page_views')
        .select('count')
        .eq('id', 'global')
        .maybeSingle();

      if (!mounted) return;
      if (data && !error) {
        setCount(data.count);
      }
    })();

    return () => {
      mounted = false;
    };
  }, []);

  return count;
}
