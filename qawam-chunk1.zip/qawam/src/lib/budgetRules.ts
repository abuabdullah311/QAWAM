import type { BudgetRule } from '@/types';

export const BUDGET_RULES: BudgetRule[] = [
  {
    id: 'balanced',
    name: '50 / 30 / 20',
    needs: 50,
    wants: 30,
    savings: 20,
    isCustom: false,
  },
  {
    id: 'aggressive',
    name: '80 / 20',
    needs: 60,
    wants: 20,
    savings: 20,
    isCustom: false,
  },
  {
    id: 'zero',
    name: 'Zero-based',
    needs: 60,
    wants: 20,
    savings: 20,
    isCustom: false,
  },
];

export const DEFAULT_RULE_ID = 'balanced';

export function getRuleById(id: string, customRule?: BudgetRule | null): BudgetRule {
  if (id === 'custom' && customRule) {
    return customRule;
  }
  return BUDGET_RULES.find(r => r.id === id) ?? BUDGET_RULES[0];
}

export const SUPPORTED_CURRENCIES: Array<{ code: import('@/types').Currency; symbol: string; label: string }> = [
  { code: 'SAR', symbol: 'ر.س', label: 'Saudi Riyal' },
  { code: 'AED', symbol: 'د.إ', label: 'UAE Dirham' },
  { code: 'USD', symbol: '$', label: 'US Dollar' },
  { code: 'EUR', symbol: '€', label: 'Euro' },
  { code: 'GBP', symbol: '£', label: 'British Pound' },
  { code: 'KWD', symbol: 'د.ك', label: 'Kuwaiti Dinar' },
  { code: 'QAR', symbol: 'ر.ق', label: 'Qatari Riyal' },
  { code: 'BHD', symbol: 'د.ب', label: 'Bahraini Dinar' },
  { code: 'OMR', symbol: 'ر.ع', label: 'Omani Rial' },
  { code: 'EGP', symbol: 'ج.م', label: 'Egyptian Pound' },
];
