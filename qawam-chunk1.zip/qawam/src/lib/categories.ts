import type { ExpenseCategory, AllocationType } from '@/types';
import {
  Home, Zap, ShoppingCart, Car, CreditCard, Tv, Shield,
  Heart, GraduationCap, UtensilsCrossed, Sparkles, ShoppingBag,
  PiggyBank, TrendingUp, HandHeart, MoreHorizontal,
  type LucideIcon,
} from 'lucide-react';

export const CATEGORY_TO_ALLOCATION: Record<ExpenseCategory, AllocationType> = {
  housing: 'needs',
  utilities: 'needs',
  groceries: 'needs',
  transportation: 'needs',
  loans: 'needs',
  insurance: 'needs',
  healthcare: 'needs',
  education: 'needs',
  subscriptions: 'wants',
  dining: 'wants',
  entertainment: 'wants',
  shopping: 'wants',
  charity: 'wants',
  savings: 'savings',
  investment: 'savings',
  other: 'wants',
};

export const CATEGORY_ICONS: Record<ExpenseCategory, LucideIcon> = {
  housing: Home,
  utilities: Zap,
  groceries: ShoppingCart,
  transportation: Car,
  loans: CreditCard,
  subscriptions: Tv,
  insurance: Shield,
  healthcare: Heart,
  education: GraduationCap,
  dining: UtensilsCrossed,
  entertainment: Sparkles,
  shopping: ShoppingBag,
  savings: PiggyBank,
  investment: TrendingUp,
  charity: HandHeart,
  other: MoreHorizontal,
};

export const ALL_CATEGORIES: ExpenseCategory[] = [
  'housing',
  'utilities',
  'groceries',
  'transportation',
  'loans',
  'insurance',
  'healthcare',
  'subscriptions',
  'dining',
  'entertainment',
  'shopping',
  'education',
  'savings',
  'investment',
  'charity',
  'other',
];
