import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    'Missing Supabase environment variables. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your .env file or Vercel environment.'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          role: 'user' | 'admin';
          language: 'en' | 'ar';
          currency: string;
          last_login: string | null;
          created_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          role?: 'user' | 'admin';
          language?: 'en' | 'ar';
          currency?: string;
          last_login?: string | null;
        };
        Update: {
          email?: string;
          full_name?: string | null;
          role?: 'user' | 'admin';
          language?: 'en' | 'ar';
          currency?: string;
          last_login?: string | null;
        };
      };
      budgets: {
        Row: {
          id: string;
          user_id: string;
          salary: number;
          currency: string;
          rule_id: string;
          custom_rule: object | null;
          expenses: object;
          updated_at: string;
          created_at: string;
        };
        Insert: {
          user_id: string;
          salary: number;
          currency: string;
          rule_id: string;
          custom_rule?: object | null;
          expenses?: object;
        };
        Update: {
          salary?: number;
          currency?: string;
          rule_id?: string;
          custom_rule?: object | null;
          expenses?: object;
        };
      };
      page_views: {
        Row: {
          id: string;
          count: number;
          updated_at: string;
        };
      };
    };
  };
};
