import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import type { Currency } from '@/types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const currencySymbols: Record<Currency, string> = {
  SAR: 'SAR',
  AED: 'AED',
  USD: '$',
  EUR: '€',
  GBP: '£',
  KWD: 'KWD',
  QAR: 'QAR',
  BHD: 'BHD',
  OMR: 'OMR',
  EGP: 'EGP',
};

export function formatCurrency(amount: number, currency: Currency, locale: 'en' | 'ar' = 'en'): string {
  const localeStr = locale === 'ar' ? 'ar-SA' : 'en-US';
  const symbol = currencySymbols[currency];
  const formatted = new Intl.NumberFormat(localeStr, {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);
  return locale === 'ar' ? `${formatted} ${symbol}` : `${symbol} ${formatted}`;
}

export function formatNumber(value: number, locale: 'en' | 'ar' = 'en'): string {
  const localeStr = locale === 'ar' ? 'ar-SA' : 'en-US';
  return new Intl.NumberFormat(localeStr).format(value);
}

export function formatPercent(value: number, locale: 'en' | 'ar' = 'en'): string {
  const localeStr = locale === 'ar' ? 'ar-SA' : 'en-US';
  return new Intl.NumberFormat(localeStr, {
    style: 'percent',
    maximumFractionDigits: 1,
  }).format(value / 100);
}

export function generateId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

export function interpolate(template: string, values: Record<string, string | number>): string {
  return template.replace(/\{(\w+)\}/g, (_, key) => String(values[key] ?? ''));
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
