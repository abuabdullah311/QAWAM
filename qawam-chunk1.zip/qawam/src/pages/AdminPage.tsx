import { AppLayout } from '@/components/layout/AppLayout';
import { Card } from '@/components/ui/Card';
import { Users } from 'lucide-react';

export function AdminPage() {
  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto">
        <Card padding="lg" className="text-center">
          <Users className="w-12 h-12 mx-auto text-brand-500 mb-3" />
          <h2 className="font-display text-2xl font-bold text-ink-900 mb-2">User Management</h2>
          <p className="text-ink-600">
            Full admin panel with user listing, role management, manual user creation, and password reset will be delivered in Chunk 2.
          </p>
        </Card>
      </div>
    </AppLayout>
  );
}
