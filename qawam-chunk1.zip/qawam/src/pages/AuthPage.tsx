import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, User as UserIcon, Languages } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { isValidEmail } from '@/lib/utils';

type Mode = 'signin' | 'signup';

export function AuthPage() {
  const { signIn, signUp } = useAuth();
  const { t, language, setLanguage } = useI18n();
  const navigate = useNavigate();

  const [mode, setMode] = useState<Mode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!isValidEmail(email)) {
      newErrors.email = t('auth.errors.invalidEmail');
    }

    if (password.length < 8) {
      newErrors.password = t('auth.errors.passwordTooShort');
    }

    if (mode === 'signup') {
      if (!fullName.trim()) {
        newErrors.fullName = t('auth.errors.nameRequired');
      }
      if (password !== confirmPassword) {
        newErrors.confirmPassword = t('auth.errors.passwordMismatch');
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitError('');
    if (!validate()) return;

    setLoading(true);
    const { error } = mode === 'signin'
      ? await signIn(email, password)
      : await signUp(email, password, fullName);
    setLoading(false);

    if (error) {
      // Translate common Supabase errors
      const lower = error.toLowerCase();
      if (lower.includes('invalid') && lower.includes('credentials')) {
        setSubmitError(t('auth.errors.invalidCredentials'));
      } else if (lower.includes('already registered') || lower.includes('already exists')) {
        setSubmitError(t('auth.errors.emailInUse'));
      } else {
        setSubmitError(error);
      }
      return;
    }

    navigate('/wizard');
  };

  const switchMode = () => {
    setMode(m => (m === 'signin' ? 'signup' : 'signin'));
    setErrors({});
    setSubmitError('');
  };

  return (
    <div className="min-h-screen flex flex-col safe-top safe-x safe-bottom">
      {/* Top bar with language toggle */}
      <div className="flex items-center justify-between p-4 sm:p-6">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold shadow-soft">
            Q
          </div>
          <span className="font-display text-xl font-bold text-ink-900">{t('common.appName')}</span>
        </div>
        <button
          onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
          className="btn-icon"
          aria-label="Switch language"
        >
          <Languages className="w-5 h-5" />
          <span className="ms-1 text-xs font-bold uppercase">{language === 'en' ? 'ع' : 'EN'}</span>
        </button>
      </div>

      {/* Centered form */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-md animate-slide-up">
          <div className="text-center mb-6 sm:mb-8">
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-ink-900 text-balance">
              {mode === 'signin' ? t('auth.welcomeBack') : t('auth.welcomeNew')}
            </h1>
            <p className="mt-2 text-ink-600 text-balance">
              {mode === 'signin' ? t('auth.signInSubtitle') : t('auth.signUpSubtitle')}
            </p>
          </div>

          <Card variant="elevated" padding="lg">
            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'signup' && (
                <Input
                  type="text"
                  name="fullName"
                  label={t('auth.fullName')}
                  placeholder={t('auth.namePlaceholder')}
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  error={errors.fullName}
                  leftIcon={<UserIcon className="w-5 h-5" />}
                  autoComplete="name"
                  required
                />
              )}

              <Input
                type="email"
                name="email"
                label={t('auth.email')}
                placeholder={t('auth.emailPlaceholder')}
                value={email}
                onChange={e => setEmail(e.target.value)}
                error={errors.email}
                leftIcon={<Mail className="w-5 h-5" />}
                autoComplete="email"
                dir="ltr"
                required
              />

              <Input
                type="password"
                name="password"
                label={t('auth.password')}
                placeholder={t('auth.passwordPlaceholder')}
                value={password}
                onChange={e => setPassword(e.target.value)}
                error={errors.password}
                leftIcon={<Lock className="w-5 h-5" />}
                autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                required
              />

              {mode === 'signup' && (
                <Input
                  type="password"
                  name="confirmPassword"
                  label={t('auth.confirmPassword')}
                  placeholder={t('auth.passwordPlaceholder')}
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  error={errors.confirmPassword}
                  leftIcon={<Lock className="w-5 h-5" />}
                  autoComplete="new-password"
                  required
                />
              )}

              {submitError && (
                <div className="p-3 rounded-xl bg-danger-50 border border-danger-200 text-sm text-danger-700">
                  {submitError}
                </div>
              )}

              <Button type="submit" size="lg" fullWidth loading={loading}>
                {mode === 'signin' ? t('auth.signInButton') : t('auth.signUpButton')}
              </Button>
            </form>

            <div className="mt-6 pt-6 border-t border-ink-100 text-center text-sm text-ink-600">
              {mode === 'signin' ? t('auth.noAccount') : t('auth.hasAccount')}{' '}
              <button
                type="button"
                onClick={switchMode}
                className="font-semibold text-brand-600 hover:text-brand-700 underline-offset-2 hover:underline"
              >
                {mode === 'signin' ? t('auth.createOne') : t('auth.signInInstead')}
              </button>
            </div>
          </Card>

          <p className="text-center text-xs text-ink-400 mt-6">{t('footer.privacy')}</p>
        </div>
      </div>
    </div>
  );
}
