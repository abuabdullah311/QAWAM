import { useNavigate } from 'react-router-dom';
import { Sparkles } from 'lucide-react';
import { AppLayout } from '@/components/layout/AppLayout';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { useI18n } from '@/contexts/I18nContext';
import { useBudget } from '@/contexts/BudgetContext';
import { formatCurrency } from '@/lib/utils';

export function DashboardPage() {
  const { t, language } = useI18n();
  const { salary, currency, expenses } = useBudget();
  const navigate = useNavigate();

  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const remaining = salary - totalExpenses;

  // Chunk 1: minimal dashboard preview. Chunk 2 will replace this with full advisor + visual breakdown + admin.
  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto space-y-5 animate-slide-up">
        <div className="text-center mb-6">
          <h1 className="font-display text-3xl font-bold text-ink-900">
            {t('common.appName')}
          </h1>
          <p className="text-ink-600 mt-1">{t('footer.tagline')}</p>
        </div>

        {salary === 0 ? (
          <Card padding="lg" className="text-center">
            <Sparkles className="w-12 h-12 mx-auto text-brand-500 mb-3" />
            <h2 className="font-display text-xl font-semibold text-ink-900 mb-2">
              {t('wizard.salary.title')}
            </h2>
            <p className="text-ink-600 mb-5">{t('wizard.salary.subtitle')}</p>
            <Button onClick={() => navigate('/wizard')}>{t('common.next')}</Button>
          </Card>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card padding="md">
                <div className="text-xs font-medium text-ink-500 uppercase mb-1">Income</div>
                <div className="font-display text-2xl font-bold text-ink-900">
                  {formatCurrency(salary, currency, language)}
                </div>
              </Card>
              <Card padding="md">
                <div className="text-xs font-medium text-ink-500 uppercase mb-1">Expenses</div>
                <div className="font-display text-2xl font-bold text-ink-900">
                  {formatCurrency(totalExpenses, currency, language)}
                </div>
              </Card>
              <Card padding="md">
                <div className="text-xs font-medium text-ink-500 uppercase mb-1">Remaining</div>
                <div className={`font-display text-2xl font-bold ${remaining >= 0 ? 'text-success-600' : 'text-danger-600'}`}>
                  {formatCurrency(remaining, currency, language)}
                </div>
              </Card>
            </div>

            <Card padding="lg" className="bg-brand-50/50 border-brand-200 text-center">
              <p className="text-ink-700">
                Full dashboard with advisor analysis, visual breakdowns, and editable expense table will be delivered in Chunk 2.
              </p>
            </Card>
          </>
        )}
      </div>
    </AppLayout>
  );
}
