import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useI18n } from '@/contexts/I18nContext';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { SalaryStep } from '@/components/wizard/SalaryStep';
import { ExpenseWizardStep } from '@/components/wizard/ExpenseWizardStep';
import { CustomExpensesStep } from '@/components/wizard/CustomExpensesStep';
import { RuleSelectionStep } from '@/components/wizard/RuleSelectionStep';
import { cn } from '@/lib/utils';

type Step = 'salary' | 'expense-wizard' | 'custom-expenses' | 'rule-selection';

const STEP_ORDER: Step[] = ['salary', 'expense-wizard', 'custom-expenses', 'rule-selection'];

export function WizardPage() {
  const { t, isRTL } = useI18n();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('salary');
  const [skippedGuided, setSkippedGuided] = useState(false);

  const stepIndex = STEP_ORDER.indexOf(step);
  // Adjust progress: 4 total perceived steps
  const progressIndex =
    step === 'salary' ? 1 :
    step === 'expense-wizard' || step === 'custom-expenses' ? 2 :
    step === 'rule-selection' ? 3 : 4;

  const handleBack = () => {
    if (step === 'salary') return;
    if (step === 'expense-wizard') setStep('salary');
    else if (step === 'custom-expenses') {
      if (skippedGuided) setStep('expense-wizard');
      else setStep('salary');
    }
    else if (step === 'rule-selection') {
      setStep(skippedGuided ? 'custom-expenses' : 'expense-wizard');
    }
  };

  const handleComplete = () => {
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex flex-col safe-top safe-bottom safe-x">
      {/* Top navigation */}
      <div className="px-4 sm:px-6 py-4 flex items-center gap-3 max-w-3xl mx-auto w-full">
        <button
          onClick={handleBack}
          disabled={step === 'salary'}
          className={cn(
            'btn-icon shrink-0',
            step === 'salary' && 'opacity-0 pointer-events-none'
          )}
          aria-label={t('common.back')}
        >
          <ArrowLeft className={cn('w-5 h-5', isRTL && 'rotate-180')} />
        </button>
        <div className="flex-1">
          <div className="text-xs font-medium text-ink-500 mb-1.5">
            {t('wizard.progress', { current: progressIndex, total: 4 })}
          </div>
          <ProgressBar current={progressIndex} total={4} />
        </div>
      </div>

      {/* Step content */}
      <div className="flex-1 px-4 sm:px-6 py-6">
        {step === 'salary' && <SalaryStep onNext={() => setStep('expense-wizard')} />}
        {step === 'expense-wizard' && (
          <ExpenseWizardStep
            onComplete={() => setStep('rule-selection')}
            onSkipToManual={() => {
              setSkippedGuided(true);
              setStep('custom-expenses');
            }}
          />
        )}
        {step === 'custom-expenses' && (
          <CustomExpensesStep onNext={() => setStep('rule-selection')} />
        )}
        {step === 'rule-selection' && <RuleSelectionStep onNext={handleComplete} />}
      </div>
    </div>
  );
}
