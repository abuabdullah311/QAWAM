export type Currency = 'SAR' | 'AED' | 'USD' | 'EUR' | 'GBP' | 'KWD' | 'QAR' | 'BHD' | 'OMR' | 'EGP';

export type UserRole = 'user' | 'admin';

export type Language = 'en' | 'ar';

export type ExpenseCategory =
  | 'housing'
  | 'utilities'
  | 'groceries'
  | 'transportation'
  | 'loans'
  | 'subscriptions'
  | 'insurance'
  | 'healthcare'
  | 'education'
  | 'dining'
  | 'entertainment'
  | 'shopping'
  | 'savings'
  | 'investment'
  | 'charity'
  | 'other';

export type AllocationType = 'needs' | 'wants' | 'savings';

export interface Expense {
  id: string;
  name: string;
  amount: number;
  category: ExpenseCategory;
  allocation: AllocationType;
  createdAt: string;
}

export interface BudgetRule {
  id: string;
  name: string;
  needs: number; // percentage 0-100
  wants: number;
  savings: number;
  isCustom: boolean;
}

export interface Profile {
  id: string;
  email: string;
  fullName: string | null;
  role: UserRole;
  language: Language;
  currency: Currency;
  lastLogin: string | null;
  createdAt: string;
}

export interface Budget {
  id: string;
  userId: string;
  salary: number;
  currency: Currency;
  ruleId: string;
  customRule: BudgetRule | null;
  expenses: Expense[];
  updatedAt: string;
}

export interface AdvisorAnalysis {
  totalIncome: number;
  totalExpenses: number;
  remaining: number;
  actual: {
    needs: number;
    wants: number;
    savings: number;
  };
  target: {
    needs: number;
    wants: number;
    savings: number;
  };
  actualPercentages: {
    needs: number;
    wants: number;
    savings: number;
  };
  breaches: AdvisorBreach[];
  isHealthy: boolean;
}

export interface AdvisorBreach {
  allocation: AllocationType;
  actualAmount: number;
  targetAmount: number;
  overage: number;
  actualPercent: number;
  targetPercent: number;
  severity: 'minor' | 'moderate' | 'severe';
}

export type WizardStep = 'salary' | 'expense-wizard' | 'custom-expenses' | 'rule-selection' | 'advisor' | 'complete';
