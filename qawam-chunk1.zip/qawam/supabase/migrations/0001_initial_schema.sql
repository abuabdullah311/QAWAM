-- ============================================================================
-- QAWAM Initial Schema Migration
-- ============================================================================
-- Run this entire file in the Supabase SQL Editor for your project.
-- This creates all tables, Row Level Security policies, RPCs, and triggers
-- required for the QAWAM platform.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. profiles table
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
    id uuid references auth.users on delete cascade primary key,
    email text not null,
    full_name text,
    role text not null default 'user' check (role in ('user', 'admin')),
    language text not null default 'en' check (language in ('en', 'ar')),
    currency text not null default 'SAR',
    last_login timestamptz,
    created_at timestamptz not null default now()
);

create index if not exists profiles_role_idx on public.profiles(role);
create index if not exists profiles_email_idx on public.profiles(email);

-- ---------------------------------------------------------------------------
-- 2. budgets table
-- ---------------------------------------------------------------------------
create table if not exists public.budgets (
    id uuid primary key default gen_random_uuid(),
    user_id uuid references auth.users on delete cascade not null unique,
    salary numeric not null default 0,
    currency text not null default 'SAR',
    rule_id text not null default 'balanced',
    custom_rule jsonb,
    expenses jsonb not null default '[]'::jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create index if not exists budgets_user_id_idx on public.budgets(user_id);

-- ---------------------------------------------------------------------------
-- 3. page_views (global counter)
-- ---------------------------------------------------------------------------
create table if not exists public.page_views (
    id text primary key,
    count bigint not null default 0,
    updated_at timestamptz not null default now()
);

-- Seed the global counter row if missing
insert into public.page_views (id, count) values ('global', 0)
on conflict (id) do nothing;

-- ---------------------------------------------------------------------------
-- 4. Helper: function to check if current user is admin
-- ---------------------------------------------------------------------------
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
    select exists (
        select 1 from public.profiles
        where id = auth.uid() and role = 'admin'
    );
$$;

-- ---------------------------------------------------------------------------
-- 5. Trigger: auto-create profile on signup
-- ---------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
    insert into public.profiles (id, email, full_name)
    values (
        new.id,
        new.email,
        coalesce(new.raw_user_meta_data->>'full_name', '')
    );
    return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
    after insert on auth.users
    for each row execute procedure public.handle_new_user();

-- ---------------------------------------------------------------------------
-- 6. Trigger: auto-update updated_at on budgets
-- ---------------------------------------------------------------------------
create or replace function public.handle_updated_at()
returns trigger
language plpgsql
as $$
begin
    new.updated_at = now();
    return new;
end;
$$;

drop trigger if exists set_updated_at on public.budgets;
create trigger set_updated_at
    before update on public.budgets
    for each row execute procedure public.handle_updated_at();

-- ---------------------------------------------------------------------------
-- 7. RPC: increment page views
-- ---------------------------------------------------------------------------
create or replace function public.increment_page_views()
returns void
language sql
security definer
set search_path = public
as $$
    insert into public.page_views (id, count, updated_at)
    values ('global', 1, now())
    on conflict (id) do update
    set count = public.page_views.count + 1, updated_at = now();
$$;

-- ---------------------------------------------------------------------------
-- 8. RPC: admin list all profiles (returns nothing for non-admins)
-- ---------------------------------------------------------------------------
create or replace function public.admin_list_profiles()
returns table (
    id uuid,
    email text,
    full_name text,
    role text,
    language text,
    currency text,
    last_login timestamptz,
    created_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
begin
    if not public.is_admin() then
        raise exception 'Permission denied';
    end if;

    return query
    select p.id, p.email, p.full_name, p.role, p.language, p.currency, p.last_login, p.created_at
    from public.profiles p
    order by p.created_at desc;
end;
$$;

-- ---------------------------------------------------------------------------
-- 9. RPC: admin update user role
-- ---------------------------------------------------------------------------
create or replace function public.admin_update_role(target_id uuid, new_role text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
    if not public.is_admin() then
        raise exception 'Permission denied';
    end if;
    if new_role not in ('user', 'admin') then
        raise exception 'Invalid role';
    end if;
    update public.profiles set role = new_role where id = target_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- 10. RPC: admin delete user (deletes from auth, cascades to profile/budget)
-- ---------------------------------------------------------------------------
create or replace function public.admin_delete_user(target_id uuid)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
    if not public.is_admin() then
        raise exception 'Permission denied';
    end if;
    if target_id = auth.uid() then
        raise exception 'Cannot delete your own account';
    end if;
    delete from auth.users where id = target_id;
end;
$$;

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

-- Enable RLS
alter table public.profiles enable row level security;
alter table public.budgets enable row level security;
alter table public.page_views enable row level security;

-- ---------------------------------------------------------------------------
-- profiles policies
-- ---------------------------------------------------------------------------
drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile"
    on public.profiles for select
    using (auth.uid() = id);

drop policy if exists "Admins can read all profiles" on public.profiles;
create policy "Admins can read all profiles"
    on public.profiles for select
    using (public.is_admin());

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
    on public.profiles for update
    using (auth.uid() = id)
    with check (auth.uid() = id and role = (select role from public.profiles where id = auth.uid()));
    -- Users cannot escalate their own role

drop policy if exists "Admins can update any profile" on public.profiles;
create policy "Admins can update any profile"
    on public.profiles for update
    using (public.is_admin());

-- ---------------------------------------------------------------------------
-- budgets policies
-- ---------------------------------------------------------------------------
drop policy if exists "Users read own budget" on public.budgets;
create policy "Users read own budget"
    on public.budgets for select
    using (auth.uid() = user_id);

drop policy if exists "Users insert own budget" on public.budgets;
create policy "Users insert own budget"
    on public.budgets for insert
    with check (auth.uid() = user_id);

drop policy if exists "Users update own budget" on public.budgets;
create policy "Users update own budget"
    on public.budgets for update
    using (auth.uid() = user_id)
    with check (auth.uid() = user_id);

drop policy if exists "Users delete own budget" on public.budgets;
create policy "Users delete own budget"
    on public.budgets for delete
    using (auth.uid() = user_id);

-- ---------------------------------------------------------------------------
-- page_views policies
-- ---------------------------------------------------------------------------
drop policy if exists "Anyone can read page views" on public.page_views;
create policy "Anyone can read page views"
    on public.page_views for select
    using (true);

-- No direct insert/update policies. Mutations only via the increment_page_views RPC,
-- which runs as security definer.

-- ============================================================================
-- GRANTS
-- ============================================================================
grant execute on function public.increment_page_views() to anon, authenticated;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.admin_list_profiles() to authenticated;
grant execute on function public.admin_update_role(uuid, text) to authenticated;
grant execute on function public.admin_delete_user(uuid) to authenticated;

-- ============================================================================
-- NOTES
-- ============================================================================
-- To promote a user to admin manually, run:
--   update public.profiles set role = 'admin' where email = 'your@email.com';
-- ============================================================================
